<?php

namespace App;

class Email extends BaseModel
{
    protected $fillable = ['id', ];
}
