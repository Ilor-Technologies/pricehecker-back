<?php

namespace App;

class AdminCreatedUser extends BaseModel
{
    protected $fillable = ['id',  'user_id' ];
}
