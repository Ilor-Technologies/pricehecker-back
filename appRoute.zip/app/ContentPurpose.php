<?php

namespace App;

class ContentPurpose extends BaseModel
{
    protected $table = 'content_purposes';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['id', ];

}
