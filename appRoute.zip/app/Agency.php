<?php

namespace App;

class Agency extends BaseModel
{
}
